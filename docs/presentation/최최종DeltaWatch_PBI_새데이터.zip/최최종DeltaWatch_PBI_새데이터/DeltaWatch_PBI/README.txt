DeltaWatch AI - Power BI 프로젝트 (새 데이터 연결본)

구성
  report\DeltaWatch.pbip   Power BI 프로젝트 (이 파일을 Power BI Desktop으로 연다)
  data_v2\*.csv            Power BI가 읽는 데이터 (raw 를 변환한 결과)
  data_v2\raw\             파이프라인 원본 export (최최종 powerbi_export.zip)
  tools\build_data_v2.py   raw -> data_v2 변환 스크립트 (검토일별 점수 재계산 포함)

열기
  1) report\DeltaWatch.pbip 열기
  2) 홈 > 새로 고침 (처음에는 이전 데이터가 보일 수 있음)

다른 위치에 압축을 풀었다면
  데이터 경로가 아래로 고정되어 있다:
    C:\Users\user\Desktop\거의 최종 DeltaWatch_PBI\data_v2\
  홈 > 데이터 변환 > 매개 변수 관리 > DataFolder 값을
  압축을 푼 위치의 data_v2 폴더 경로(끝에 \ 포함)로 바꾼 뒤 새로 고침.

데이터를 다시 만들 때
  data_v2\raw 의 CSV를 새 export로 바꾸고, 이 폴더에서
    python tools\build_data_v2.py
  실행 후 Power BI에서 새로 고침.
