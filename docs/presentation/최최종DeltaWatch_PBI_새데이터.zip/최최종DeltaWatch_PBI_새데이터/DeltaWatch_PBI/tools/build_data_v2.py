"""data_v2/raw (파이프라인 원본 export) -> data_v2/*.csv (Power BI 모델이 읽는 형식)

모델 테이블 형식은 기존 data/ 와 같다. 검토일별 점수(fact_priority_calc, fact_rule_hit_calc)는
레퍼런스(reference/deltawatch-reference.html)의 점수 엔진과 같은 방식으로 다시 계산한다.
  - 재무 Rule·D1(공시와 무관): 기준 실행(BASE_RUN)의 결과를 그대로 사용
  - 공시 Rule(D2~D10): 검토일 이후 공시만. 파이프라인이 판정한 공시는 그 판정, 나머지는 공시명 키워드
  - 총점 = 즉시상향 Rule(또는 F1+F2 동시)이면 10, 아니면 재무·공시·정정 중 3점 이상인 최댓값

사용: python tools/build_data_v2.py  (프로젝트 루트에서)
"""
import csv
import os
import re
from collections import defaultdict
from datetime import date, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(ROOT, "data_v2", "raw")
OUT = os.path.join(ROOT, "data_v2")

BASE_RUN = "2026-10-12"  # 전체 기업이 들어 있는 마지막 파이프라인 실행
REVIEW_DATES = [  # (검토일, 라벨) — 슬라이서 순서대로
    ("2026-10-01", "2026.10.01 · 최근 1주"),
    ("2026-09-01", "2026.09.01 · 월간 점검"),
    ("2026-08-27", "2026.08.27 · 기준금리 인상 (2.75→3.00%)"),
    ("2026-07-16", "2026.07.16 · 기준금리 인상 (2.50→2.75%)"),
    ("2026-07-01", "2026.07.01 · 하반기 시작"),
    ("2026-04-01", "2026.04.01 · 2분기 시작"),
]
DEFAULT_REVIEW = "2026-08-27"
ACCOUNT_SORT = {"REVENUE": 1, "OP_INCOME": 2, "OCF": 3, "TOTAL_LIAB": 4, "TOTAL_EQUITY": 5,
                "BORROWINGS": 6, "ST_BORROWINGS": 7, "NET_INCOME": 8}
GRADE_KR = {"emergency": ("긴급", 1), "high": ("높음", 2), "mid": ("중간", 3), "low": ("낮음", 4), "none": ("변화 없음", 5)}

# 공시명 키워드 판정 (레퍼런스 KW + 새 Rule D10)
KW = [
    ("D2", lambda n: re.search(r"유상증자결정", n)),
    ("D3", lambda n: re.search(r"감사의견\s*거절|의견거절|부적정|감사의견\s*한정", n)),
    ("D4", lambda n: re.search(r"최대주주변경", n) and not re.search(r"주식담보", n)),
    ("D6A", lambda n: re.search(r"단일판매ㆍ공급계약체결", n)),
    ("D6B", lambda n: re.search(r"신규시설투자", n)),
    ("D6C", lambda n: re.search(r"타법인주식및출자증권(취득|양수)결정", n)),
    ("D6D", lambda n: re.search(r"계약\s*해지", n)),
    ("D7", lambda n: re.search(r"상장폐지|관리종목|상장적격성", n)),
    ("D8", lambda n: re.search(r"매매거래정지|회생절차|부도", n)),
    ("D9", lambda n: re.search(r"영업정지|사업중단", n)),
    ("D10", lambda n: re.search(r"채무보증|담보제공", n)),
]


def d5_score(name):
    if "감사보고서" in name:
        return 9
    if re.search(r"사업보고서|분기보고서|반기보고서", name):
        return 6
    return 3


def read(name):
    with open(os.path.join(RAW, name), encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write(name, header, rows):
    with open(os.path.join(OUT, name), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, lineterminator="\r\n")
        w.writerow(header)
        for r in rows:
            w.writerow([r.get(h, "") for h in header])
    print(f"{name}: {len(rows)}")


def eok(v):
    return "" if v in ("", None) else str(round(float(v) / 1e8, 1))


def changed_span(a, b):
    """앞뒤 공통 단어를 걷어낸 나머지 = 삭제된 표현 / 추가된 표현"""
    A, B = a.split(), b.split()
    i = 0
    while i < min(len(A), len(B)) and A[i] == B[i]:
        i += 1
    j = 0
    while j < min(len(A), len(B)) - i and A[-1 - j] == B[-1 - j]:
        j += 1
    return " ".join(A[i:len(A) - j]), " ".join(B[i:len(B) - j])


def main():
    companies = read("dim_company.csv")
    name_of = {c["corp_code"]: c["company_name"] for c in companies}
    rules = read("dim_rule.csv")
    rule = {r["rule_id"]: r for r in rules}
    immediate = {r["rule_id"] for r in rules if r["rule_group"] == "즉시상향"}
    disc = read("fact_disclosure.csv")
    diff = read("fact_disclosure_diff.csv")
    expl = read("fact_explanation.csv")
    hits = read("fact_rule_hit.csv")
    end = max(d["rcept_date"] for d in disc)

    # --- 차원 ---
    write("dim_company.csv", ["corp_code", "stock_code", "company_name"], companies)
    write("dim_rule.csv", ["rule_id", "rule_group", "rule_name", "condition_text", "score"], rules)
    acc = read("dim_account.csv")
    for a in acc:
        a["sort_order"] = ACCOUNT_SORT.get(a["account_id"], 99)
    write("dim_account.csv", ["account_id", "account_name", "unit", "sort_order"], acc)
    write("dim_review_date.csv", ["review_date", "review_label", "sort_order", "is_default"],
          [{"review_date": d, "review_label": l, "sort_order": i + 1, "is_default": int(d == DEFAULT_REVIEW)}
           for i, (d, l) in enumerate(REVIEW_DATES)])
    write("fact_base_rate.csv", ["date", "rate", "prev_rate", "direction"], read("fact_base_rate.csv"))
    write("fact_explanation.csv", ["rcept_no", "sentence_seq", "sentence", "evidence_rcept_no", "evidence_location",
                                   "evidence_excerpt"], expl)

    # --- 공시 ---
    has_diff = {d["rcept_no"] for d in diff}
    has_expl = {e["rcept_no"] for e in expl}
    for d in disc:
        dt = date.fromisoformat(d["rcept_date"])
        d["company_name"] = name_of.get(d["corp_code"], "")
        d["week_start"] = (dt - timedelta(days=dt.weekday())).isoformat()
        d["has_diff"] = int(d["rcept_no"] in has_diff)
        d["has_explanation"] = int(d["rcept_no"] in has_expl)
    write("fact_disclosure.csv", ["rcept_no", "corp_code", "company_name", "rcept_date", "week_start", "report_name",
                                  "disclosure_type", "orig_rcept_no", "url", "has_diff", "has_explanation"], disc)
    for r in diff:
        r["removed_words"], r["added_words"] = changed_span(r["before_text"], r["after_text"])
    write("fact_disclosure_diff.csv", ["rcept_no", "orig_rcept_no", "item_seq", "item_name", "before_text",
                                       "after_text", "removed_words", "added_words"], diff)

    fin = read("fact_financial_change.csv")
    for r in fin:
        r["prev_eok"], r["curr_eok"] = eok(r["prev_value"]), eok(r["curr_value"])
    write("fact_financial_change.csv", ["corp_code", "report_period", "rcept_no", "account_id", "fs_div", "prev_value",
                                        "curr_value", "prev_eok", "curr_eok", "change_pct", "change_label"], fin)

    # --- 검토일별 점수 ---
    known = defaultdict(dict)  # rcept_no -> {rule_id: score} (파이프라인이 판정한 공시)
    for h in hits:
        if h["rcept_no"]:
            k = known[h["rcept_no"]]
            k[h["rule_id"]] = max(k.get(h["rule_id"], 0), int(h["score"]))
    base = [h for h in hits if h["review_date"] == BASE_RUN and not h["rcept_no"]]
    assert {h["corp_code"] for h in hits if h["review_date"] == BASE_RUN} <= set(name_of)

    def classify(d):
        if d["rcept_no"] in known:
            return [(rid, sc, "파이프라인") for rid, sc in known[d["rcept_no"]].items()]
        out = [(rid, int(rule[rid]["score"]), "공시명 판정") for rid, f in KW if f(d["report_name"])]
        if d["disclosure_type"] == "정정":
            out.append(("D5", d5_score(d["report_name"]), "공시명 판정"))
        return out

    cls = {d["rcept_no"]: classify(d) for d in disc}
    pri_rows, hit_rows = [], []
    for last, _ in REVIEW_DATES:
        hs = [dict(corp_code=h["corp_code"], rule_id=h["rule_id"], score=int(h["score"]), rcept_no="", event_date="",
                   prev_value=h["prev_value"], curr_value=h["curr_value"], source="파이프라인", url="") for h in base]
        for d in disc:
            if last < d["rcept_date"] <= end:
                for rid, sc, src in cls[d["rcept_no"]]:
                    hs.append(dict(corp_code=d["corp_code"], rule_id=rid, score=sc, rcept_no=d["rcept_no"],
                                   event_date=d["rcept_date"], prev_value="", curr_value="", source=src, url=d["url"]))
        rows = []
        for c in companies:
            cc = c["corp_code"]
            mine = [h for h in hs if h["corp_code"] == cc]
            mx = lambda f: max([0] + [h["score"] for h in mine if f(h["rule_id"])])
            f_s = mx(lambda r: r.startswith("F"))
            c_s = mx(lambda r: r == "D5")
            e_s = mx(lambda r: r.startswith("D") and r != "D5")
            ids = {h["rule_id"] for h in mine}
            override = bool(ids & immediate) or {"F1", "F2"} <= ids
            total = 10 if override else max([0] + [v for v in (f_s, e_s, c_s) if v >= 3])
            grade = ("emergency" if override else "high" if total >= 8 else "mid" if total >= 3
                     else "low" if total >= 1 else "none")
            top, seen = [], set()
            for h in sorted(mine, key=lambda h: (-h["score"], not h["rule_id"].startswith("F"))):
                if h["rule_id"] not in seen:
                    seen.add(h["rule_id"])
                    top.append(f'{h["rule_id"]} {rule[h["rule_id"]]["rule_name"]}')
            top += [""] * 3
            rows.append(dict(review_date=last, corp_code=cc, company_name=c["company_name"], total_score=total,
                             score_financial=f_s, score_event=e_s, score_correction=c_s, grade=grade,
                             grade_kr=GRADE_KR[grade][0], grade_order=GRADE_KR[grade][1],
                             override_flag="TRUE" if override else "FALSE", top_change_1=top[0],
                             top_change_2=top[1], top_change_3=top[2],
                             has_keyword_rule=int(any(h["source"] == "공시명 판정" for h in mine))))
        for r in rows:
            r["rank"] = 1 + sum(1 for o in rows if o["total_score"] > r["total_score"])
            r["rank_label"] = f'{r["rank"]}. {r["company_name"]}'
        rows.sort(key=lambda r: (r["rank"], r["grade_order"], -r["score_financial"], r["company_name"]))
        pri_rows += rows
        rk = {r["corp_code"]: r for r in rows}
        for h in hs:
            p = rk[h["corp_code"]]
            hit_rows.append(dict(review_date=last, company_name=p["company_name"], rank=p["rank"],
                                 rank_label=p["rank_label"], rule_name=rule[h["rule_id"]]["rule_name"],
                                 rule_group=rule[h["rule_id"]]["rule_group"], **h))
    write("fact_priority_calc.csv", ["review_date", "corp_code", "company_name", "rank_label", "total_score",
                                     "score_financial", "score_event", "score_correction", "grade", "grade_kr",
                                     "grade_order", "override_flag", "rank", "top_change_1", "top_change_2",
                                     "top_change_3", "has_keyword_rule"], pri_rows)
    write("fact_rule_hit_calc.csv", ["review_date", "corp_code", "company_name", "rank", "rank_label", "rule_id",
                                     "rule_name", "rule_group", "score", "rcept_no", "event_date", "prev_value",
                                     "curr_value", "source", "url"], hit_rows)


if __name__ == "__main__":
    main()
